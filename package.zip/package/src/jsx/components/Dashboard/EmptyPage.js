import React from "react";

const EmptyPage = () => {
 
  return (
		<>	
		</>
	);
};

export default EmptyPage;
